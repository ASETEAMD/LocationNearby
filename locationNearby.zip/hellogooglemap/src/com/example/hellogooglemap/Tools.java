package com.example.hellogooglemap;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.util.Log;


public class Tools {

	public static final String PLACE_REFRANCE = "refranceString";
	
	 public static String getLocation(Context context){
	    	LocationManager locationManager = (LocationManager)context.getSystemService(Context.LOCATION_SERVICE);
			Location location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
			
			if(location == null){
				return "";
			}
			double longitude = location.getLongitude();
			double latitude = location.getLatitude();
			Log.i("tag", "location is " + longitude + "," + latitude);
			return latitude+","+longitude;
		}
	 
	 
	 public static List<MyGoogleBean> formatJsonTOBean(String resultString) throws JSONException{
		 List<MyGoogleBean> myGoogleBeans = new ArrayList<MyGoogleBean>();
		 JSONObject clientResonseJsonObjetc = new JSONObject(resultString);
		 JSONArray jsonArray = clientResonseJsonObjetc.getJSONArray("results");

			for (int i = 0; i < jsonArray.length(); i++) {
				JSONObject jsonObject = jsonArray.getJSONObject(i);
				String name = jsonObject.getString("name");
				String address = jsonObject.getString("vicinity");
				String reference = jsonObject.getString("reference");
				myGoogleBeans.add(new MyGoogleBean(name, address,reference));
			}
		 return myGoogleBeans;
	 }
}