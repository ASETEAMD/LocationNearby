/** Automatically generated file. DO NOT MODIFY */
package com.example.hellogooglemap;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}